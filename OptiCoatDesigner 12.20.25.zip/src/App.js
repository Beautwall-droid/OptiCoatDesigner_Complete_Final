import OptiCoatDesigner from "./OptiCoatDesigner_Complete_Final";

function App() {
  return <OptiCoatDesigner />;
}

export default App;
